plugins { id("com.android.application") }
android {
 namespace = "com.parkarsite.g6astability64"
 compileSdk = 36
 defaultConfig { applicationId = "com.parkarsite.g6astability64"; minSdk = 26; targetSdk = 36; versionCode = 2; versionName = "0.6.4.1" }
 buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
